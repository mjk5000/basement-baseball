// Game state
let gameState = {
    homeScore: 0,
    awayScore: 0,
    homeHits: 0,
    awayHits: 0,
    homeErrors: 0,
    awayErrors: 0,
    inning: 1,
    inningHalf: 'top', // 'top' or 'bottom'
    outs: 0,
    strikes: 0,
    balls: 0,
    runners: {
        first: false,
        second: false,
        third: false
    },
    currentContact: null,
    homeInnings: ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
    awayInnings: ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
    currentInningRuns: 0,
    lastPlay: '',
    strikeouts: 0,
    // Batting lineups
    homeLineup: [
        { name: 'Smith', pos: 'CF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Jones', pos: 'SS', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Garcia', pos: 'RF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Johnson', pos: '1B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Williams', pos: 'LF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Davis', pos: '3B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Miller', pos: '2B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Rodriguez', pos: 'C', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Kajewski', pos: 'P', ab: 0, h: 0, k: 0, bb: 0, r: 0 }
    ],
    awayLineup: [
        { name: 'Brown', pos: 'CF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Wilson', pos: 'SS', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Anderson', pos: 'RF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Taylor', pos: '1B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Thomas', pos: 'LF', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Moore', pos: '3B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Jackson', pos: '2B', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'White', pos: 'C', ab: 0, h: 0, k: 0, bb: 0, r: 0 },
        { name: 'Kajewski', pos: 'P', ab: 0, h: 0, k: 0, bb: 0, r: 0 }
    ],
    currentHomeBatter: 0,
    currentAwayBatter: 0
};

// DOM elements
const homeScoreEl = document.getElementById('homeScore');
const awayScoreEl = document.getElementById('awayScore');
const homeHitsEl = document.getElementById('homeHits');
const awayHitsEl = document.getElementById('awayHits');
const homeErrorsEl = document.getElementById('homeErrors');
const awayErrorsEl = document.getElementById('awayErrors');
const inningEl = document.getElementById('inning');
const messageEl = document.getElementById('message');
const pitchInputEl = document.getElementById('pitchInput');
const qualityInputEl = document.getElementById('qualityInput');
const batterEl = document.getElementById('batter');

// Home run animation tracking
let homeRunAnimationInterval = null;
let homeRunAnimationCount = 0;

// Game state history for undo functionality
let gameStateHistory = [];
const MAX_HISTORY = 50; // Keep last 50 states

// Save current state to history
function saveState() {
    // Deep clone the current state
    const stateCopy = JSON.parse(JSON.stringify({
        homeScore: gameState.homeScore,
        awayScore: gameState.awayScore,
        homeHits: gameState.homeHits,
        awayHits: gameState.awayHits,
        homeErrors: gameState.homeErrors,
        awayErrors: gameState.awayErrors,
        inning: gameState.inning,
        inningHalf: gameState.inningHalf,
        outs: gameState.outs,
        strikes: gameState.strikes,
        balls: gameState.balls,
        runners: gameState.runners,
        homeInnings: gameState.homeInnings,
        awayInnings: gameState.awayInnings,
        currentInningRuns: gameState.currentInningRuns,
        lastPlay: gameState.lastPlay,
        strikeouts: gameState.strikeouts,
        homeLineup: gameState.homeLineup,
        awayLineup: gameState.awayLineup,
        currentHomeBatter: gameState.currentHomeBatter,
        currentAwayBatter: gameState.currentAwayBatter
    }));
    
    gameStateHistory.push(stateCopy);
    
    // Keep history size manageable
    if (gameStateHistory.length > MAX_HISTORY) {
        gameStateHistory.shift();
    }
    
    updateUndoButton();
}

// Undo last action
function undoLastAction() {
    if (gameStateHistory.length === 0) {
        showMessage('Nothing to undo!');
        return;
    }
    
    // Get the last saved state
    const previousState = gameStateHistory.pop();
    
    // Restore all state properties
    gameState.homeScore = previousState.homeScore;
    gameState.awayScore = previousState.awayScore;
    gameState.homeHits = previousState.homeHits;
    gameState.awayHits = previousState.awayHits;
    gameState.homeErrors = previousState.homeErrors;
    gameState.awayErrors = previousState.awayErrors;
    gameState.inning = previousState.inning;
    gameState.inningHalf = previousState.inningHalf;
    gameState.outs = previousState.outs;
    gameState.strikes = previousState.strikes;
    gameState.balls = previousState.balls;
    gameState.runners = previousState.runners;
    gameState.homeInnings = previousState.homeInnings;
    gameState.awayInnings = previousState.awayInnings;
    gameState.currentInningRuns = previousState.currentInningRuns;
    gameState.lastPlay = previousState.lastPlay;
    gameState.strikeouts = previousState.strikeouts;
    gameState.homeLineup = previousState.homeLineup;
    gameState.awayLineup = previousState.awayLineup;
    gameState.currentHomeBatter = previousState.currentHomeBatter;
    gameState.currentAwayBatter = previousState.currentAwayBatter;
    
    updateDisplay();
    updateUndoButton();
    showMessage('Action undone! ↩️');
}

// Update undo button state
function updateUndoButton() {
    const undoBtn = document.getElementById('undoBtn');
    if (undoBtn) {
        undoBtn.disabled = gameStateHistory.length === 0;
        undoBtn.style.opacity = gameStateHistory.length === 0 ? '0.5' : '1';
    }
}

// Shuffle array function for randomizing lineups
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Initialize game with random lineups
function initializeGame() {
    // Randomly assign Kajewski's position in each lineup
    const positions = ['CF', 'SS', 'RF', '1B', 'LF', '3B', '2B', 'C', 'P'];
    
    // Find Kajewski in home lineup and swap position with a random player
    const homeKajewskiIndex = gameState.homeLineup.findIndex(p => p.name === 'Kajewski');
    if (homeKajewskiIndex !== -1) {
        const randomIndex = Math.floor(Math.random() * 9);
        const tempPos = gameState.homeLineup[homeKajewskiIndex].pos;
        gameState.homeLineup[homeKajewskiIndex].pos = gameState.homeLineup[randomIndex].pos;
        gameState.homeLineup[randomIndex].pos = tempPos;
    }
    
    // Find Kajewski in away lineup and swap position with a random player
    const awayKajewskiIndex = gameState.awayLineup.findIndex(p => p.name === 'Kajewski');
    if (awayKajewskiIndex !== -1) {
        const randomIndex = Math.floor(Math.random() * 9);
        const tempPos = gameState.awayLineup[awayKajewskiIndex].pos;
        gameState.awayLineup[awayKajewskiIndex].pos = gameState.awayLineup[randomIndex].pos;
        gameState.awayLineup[randomIndex].pos = tempPos;
    }
    
    // Shuffle the batting orders
    gameState.homeLineup = shuffleArray(gameState.homeLineup);
    gameState.awayLineup = shuffleArray(gameState.awayLineup);
    updateDisplay();
    updateUndoButton(); // Initialize undo button state
}

// Call initialize when page loads
window.addEventListener('DOMContentLoaded', initializeGame);

// Update display
function updateDisplay() {
    homeScoreEl.textContent = gameState.homeScore;
    awayScoreEl.textContent = gameState.awayScore;
    homeHitsEl.textContent = gameState.homeHits;
    awayHitsEl.textContent = gameState.awayHits;
    homeErrorsEl.textContent = gameState.homeErrors;
    awayErrorsEl.textContent = gameState.awayErrors;
    inningEl.textContent = gameState.inning;
    updateCountCircles();
    updateDiamond();
    updateScoreboard();
    updateInningIndicator();
    updateBaseIndicators();
    updateLineups();
}

// Update lineups display
function updateLineups() {
    const homeLineupEl = document.querySelector('.home-lineup');
    const awayLineupEl = document.querySelector('.away-lineup');
    
    // Show/hide lineups based on who's batting
    if (gameState.inningHalf === 'top') {
        awayLineupEl.classList.remove('lineup-hidden');
        homeLineupEl.classList.add('lineup-hidden');
    } else {
        homeLineupEl.classList.remove('lineup-hidden');
        awayLineupEl.classList.add('lineup-hidden');
    }
    
    // Update home lineup
    for (let i = 0; i < 9; i++) {
        const player = gameState.homeLineup[i];
        const battingNow = gameState.inningHalf === 'bottom' && i === gameState.currentHomeBatter;
        const spotEl = document.getElementById(`home-batter-${i + 1}`);
        if (spotEl) {
            const avg = player.ab > 0 ? (player.h / player.ab).toFixed(3).substring(1) : '.000';
            const stats = `${player.h}-${player.ab}${player.k > 0 ? ' ' + player.k + 'K' : ''}${player.bb > 0 ? ' ' + player.bb + 'BB' : ''}`;
            // Add extra spaces for single-letter positions (C, P)
            const posDisplay = (player.pos === 'C' || player.pos === 'P') ? `${player.pos}  ` : player.pos;
            spotEl.innerHTML = `<div>${posDisplay} ${player.name}</div><div class="player-stats">${stats}</div>`;
            // Apply batting-now class to the batter-spot element
            if (battingNow) {
                spotEl.classList.add('batting-now');
            } else {
                spotEl.classList.remove('batting-now');
            }
        }
    }
    
    // Update away lineup
    for (let i = 0; i < 9; i++) {
        const player = gameState.awayLineup[i];
        const battingNow = gameState.inningHalf === 'top' && i === gameState.currentAwayBatter;
        const spotEl = document.getElementById(`away-batter-${i + 1}`);
        if (spotEl) {
            const avg = player.ab > 0 ? (player.h / player.ab).toFixed(3).substring(1) : '.000';
            const stats = `${player.h}-${player.ab}${player.k > 0 ? ' ' + player.k + 'K' : ''}${player.bb > 0 ? ' ' + player.bb + 'BB' : ''}`;
            // Add extra spaces for single-letter positions (C, P)
            const posDisplay = (player.pos === 'C' || player.pos === 'P') ? `${player.pos}  ` : player.pos;
            spotEl.innerHTML = `<div>${posDisplay} ${player.name}</div><div class="player-stats">${stats}</div>`;
            // Apply batting-now class to the batter-spot element
            if (battingNow) {
                spotEl.classList.add('batting-now');
            } else {
                spotEl.classList.remove('batting-now');
            }
        }
    }
}

// Update count circles (balls, strikes, outs)
function updateCountCircles() {
    // Update balls (max 3 shown)
    for (let i = 1; i <= 3; i++) {
        const circle = document.getElementById(`ball-${i}`);
        if (circle) {
            circle.classList.toggle('filled', i <= gameState.balls);
        }
    }
    
    // Update strikes (max 2 shown)
    for (let i = 1; i <= 2; i++) {
        const circle = document.getElementById(`strike-${i}`);
        if (circle) {
            circle.classList.toggle('filled', i <= gameState.strikes);
        }
    }
    
    // Update outs (max 2 shown)
    for (let i = 1; i <= 2; i++) {
        const circle = document.getElementById(`out-${i}`);
        if (circle) {
            circle.classList.toggle('filled', i <= gameState.outs);
        }
    }
}

// Update MLB scoreboard
function updateScoreboard() {
    // Remove all current inning highlighting first
    for (let i = 1; i <= 9; i++) {
        const homeCell = document.getElementById(`home-inning-${i}`);
        const awayCell = document.getElementById(`away-inning-${i}`);
        if (homeCell) {
            homeCell.classList.remove('current-inning-home');
        }
        if (awayCell) {
            awayCell.classList.remove('current-inning-away');
        }
    }
    
    // Update home innings
    for (let i = 0; i < 9; i++) {
        const cell = document.getElementById(`home-inning-${i + 1}`);
        if (cell) {
            const value = gameState.homeInnings[i];
            cell.textContent = value === '-' ? '-' : value;
        }
    }
    // Update away innings
    for (let i = 0; i < 9; i++) {
        const cell = document.getElementById(`away-inning-${i + 1}`);
        if (cell) {
            const value = gameState.awayInnings[i];
            cell.textContent = value === '-' ? '-' : value;
        }
    }
    
    // Update current inning live and add highlighting
    const currentInningIndex = gameState.inning - 1;
    if (currentInningIndex >= 0 && currentInningIndex < 9) {
        if (gameState.inningHalf === 'top') {
            const cell = document.getElementById(`away-inning-${gameState.inning}`);
            if (cell) {
                // Update live display during the inning
                if (gameState.awayInnings[currentInningIndex] === '-' || gameState.outs < 3) {
                    cell.textContent = gameState.currentInningRuns;
                }
                // Add highlighting to current inning
                cell.classList.add('current-inning-away');
            }
        } else {
            const cell = document.getElementById(`home-inning-${gameState.inning}`);
            if (cell) {
                // Update live display during the inning
                if (gameState.homeInnings[currentInningIndex] === '-' || gameState.outs < 3) {
                    cell.textContent = gameState.currentInningRuns;
                }
                // Add highlighting to current inning
                cell.classList.add('current-inning-home');
            }
        }
    }
}

// Update inning indicator (top/bottom)
function updateInningIndicator() {
    const topIndicator = document.querySelector('.top-indicator');
    const bottomIndicator = document.querySelector('.bottom-indicator');
    
    if (topIndicator && bottomIndicator) {
        topIndicator.classList.toggle('active', gameState.inningHalf === 'top');
        bottomIndicator.classList.toggle('active', gameState.inningHalf === 'bottom');
    }
}

// Update base indicators (SVG)
function updateBaseIndicators() {
    const base1Indicator = document.getElementById('base1-indicator');
    const base2Indicator = document.getElementById('base2-indicator');
    const base3Indicator = document.getElementById('base3-indicator');
    
    // Determine which team is batting for color
    const battingClass = gameState.inningHalf === 'top' ? 'away-batting' : 'home-batting';
    
    if (base1Indicator) {
        base1Indicator.classList.toggle('runner-on', gameState.runners.first);
        base1Indicator.classList.remove('away-batting', 'home-batting');
        if (gameState.runners.first) base1Indicator.classList.add(battingClass);
    }
    if (base2Indicator) {
        base2Indicator.classList.toggle('runner-on', gameState.runners.second);
        base2Indicator.classList.remove('away-batting', 'home-batting');
        if (gameState.runners.second) base2Indicator.classList.add(battingClass);
    }
    if (base3Indicator) {
        base3Indicator.classList.toggle('runner-on', gameState.runners.third);
        base3Indicator.classList.remove('away-batting', 'home-batting');
        if (gameState.runners.third) base3Indicator.classList.add(battingClass);
    }
}

// Update diamond display
function updateDiamond() {
    const base1 = document.getElementById('base1');
    const base2 = document.getElementById('base2');
    const base3 = document.getElementById('base3');
    
    const runner1 = document.getElementById('runner1');
    const runner2 = document.getElementById('runner2');
    const runner3 = document.getElementById('runner3');
    
    // Update base highlighting if elements exist
    if (base1) base1.classList.toggle('has-runner', gameState.runners.first);
    if (base2) base2.classList.toggle('has-runner', gameState.runners.second);
    if (base3) base3.classList.toggle('has-runner', gameState.runners.third);
    
    // Show/hide runners only when on base
    if (runner1) runner1.classList.toggle('visible', gameState.runners.first);
    if (runner2) runner2.classList.toggle('visible', gameState.runners.second);
    if (runner3) runner3.classList.toggle('visible', gameState.runners.third);
}

// Animate runner movement
function animateRunners() {
    const runners = document.querySelectorAll('.runner.visible');
    runners.forEach(runner => {
        runner.classList.add('running');
        setTimeout(() => runner.classList.remove('running'), 500);
    });
}

// Flash runner on base (for hits)
function flashRunner(baseNumber) {
    const baseIndicator = document.getElementById(`base${baseNumber}-indicator`);
    if (baseIndicator) {
        // Flash twice
        baseIndicator.style.animation = 'none';
        setTimeout(() => {
            baseIndicator.style.animation = 'flashBase 0.3s ease-in-out 2';
        }, 10);
    }
}

// Flash home plate when runner scores
function flashHomePlate() {
    const homeIndicator = document.getElementById('home-indicator');
    if (homeIndicator) {
        homeIndicator.style.animation = 'none';
        setTimeout(() => {
            homeIndicator.style.animation = 'flashBase 0.4s ease-in-out 3';
        }, 10);
    }
}

// Show X on base where out occurred
function showOutX(position) {
    const validPositions = ['base1-out', 'base2-out', 'base3-out', 'home-out', 'P-out', 'SS-out', '2B-out', 'LF-out', 'CF-out', 'RF-out', 'C-out'];
    
    let markerId;
    // Handle both base numbers and position codes
    if (position === 1) markerId = 'base1-out';
    else if (position === 2) markerId = 'base2-out';
    else if (position === 3) markerId = 'base3-out';
    else if (position === 'home') markerId = 'home-out';
    else markerId = position + '-out';
    
    const outMarker = document.getElementById(markerId);
    if (outMarker) {
        // Remove any existing animation
        outMarker.classList.remove('show');
        
        // Force reflow to restart animation
        void outMarker.offsetWidth;
        
        // Add show class to trigger animation
        outMarker.classList.add('show');
        
        // Remove class after animation completes
        setTimeout(() => {
            outMarker.classList.remove('show');
        }, 2500);
    } else {
        console.log('Out marker not found for position:', position, 'tried:', markerId);
    }
}

// Animate home run - show runner going around all bases
// Animate home run - show runner going around all bases with flashing
function animateHomeRunBases() {
    // Stop any existing animation
    stopHomeRunAnimation();
    
    const base1 = document.getElementById('base1-indicator');
    const base2 = document.getElementById('base2-indicator');
    const base3 = document.getElementById('base3-indicator');
    const homeBase = document.querySelector('.home-indicator');
    const battingClass = gameState.inningHalf === 'top' ? 'away-batting' : 'home-batting';
    
    homeRunAnimationCount = 0;
    let isLit = false;
    
    // Flash all bases including home plate 5 times
    homeRunAnimationInterval = setInterval(() => {
        if (isLit) {
            // Turn off
            if (base1) base1.classList.remove('runner-on', 'away-batting', 'home-batting');
            if (base2) base2.classList.remove('runner-on', 'away-batting', 'home-batting');
            if (base3) base3.classList.remove('runner-on', 'away-batting', 'home-batting');
            if (homeBase) homeBase.classList.remove('runner-on', 'away-batting', 'home-batting');
            homeRunAnimationCount++;
        } else {
            // Turn on
            if (base1) base1.classList.add('runner-on', battingClass);
            if (base2) base2.classList.add('runner-on', battingClass);
            if (base3) base3.classList.add('runner-on', battingClass);
            if (homeBase) homeBase.classList.add('runner-on', battingClass);
        }
        
        isLit = !isLit;
        
        // Stop after 5 complete flashes (10 toggles)
        if (homeRunAnimationCount >= 5) {
            stopHomeRunAnimation();
        }
    }, 300); // Flash every 300ms
}

// Stop home run animation
function stopHomeRunAnimation() {
    if (homeRunAnimationInterval) {
        clearInterval(homeRunAnimationInterval);
        homeRunAnimationInterval = null;
        homeRunAnimationCount = 0;
        
        // Clear all bases
        const base1 = document.getElementById('base1-indicator');
        const base2 = document.getElementById('base2-indicator');
        const base3 = document.getElementById('base3-indicator');
        const homeBase = document.querySelector('.home-indicator');
        
        if (base1) base1.classList.remove('runner-on', 'away-batting', 'home-batting');
        if (base2) base2.classList.remove('runner-on', 'away-batting', 'home-batting');
        if (base3) base3.classList.remove('runner-on', 'away-batting', 'home-batting');
        if (homeBase) homeBase.classList.remove('runner-on', 'away-batting', 'home-batting');
    }
}

// Launch fireworks for home runs
function launchFireworks() {
    const container = document.getElementById('fireworksContainer');
    if (!container) return;
    
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ff8800', '#ff0088'];
    const fireworkCount = 5;
    
    for (let f = 0; f < fireworkCount; f++) {
        setTimeout(() => {
            // Random position across entire screen
            const x = Math.random() * window.innerWidth;
            const y = Math.random() * window.innerHeight;
            
            // Create 40 particles per firework for more impressive display
            for (let i = 0; i < 40; i++) {
                const particle = document.createElement('div');
                particle.className = 'firework';
                particle.style.left = x + 'px';
                particle.style.top = y + 'px';
                particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                
                // Random direction in full circle
                const angle = (Math.PI * 2 * i) / 40;
                const velocity = 80 + Math.random() * 80; // Increased velocity for bigger spread
                const tx = Math.cos(angle) * velocity;
                const ty = Math.sin(angle) * velocity;
                
                particle.style.setProperty('--tx', tx + 'px');
                particle.style.setProperty('--ty', ty + 'px');
                
                container.appendChild(particle);
                
                // Remove particle after animation (matching CSS duration)
                setTimeout(() => {
                    particle.remove();
                }, 2500);
            }
        }, f * 400); // Stagger fireworks every 400ms
    }
}

// Get current batter
function getCurrentBatter() {
    if (gameState.inningHalf === 'top') {
        return gameState.awayLineup[gameState.currentAwayBatter];
    } else {
        return gameState.homeLineup[gameState.currentHomeBatter];
    }
}

// Advance to next batter
function nextBatter() {
    if (gameState.inningHalf === 'top') {
        gameState.currentAwayBatter = (gameState.currentAwayBatter + 1) % 9;
    } else {
        gameState.currentHomeBatter = (gameState.currentHomeBatter + 1) % 9;
    }
}

// Record at-bat
function recordAtBat(result) {
    const batter = getCurrentBatter();
    
    switch(result) {
        case 'hit':
            batter.ab++;
            batter.h++;
            // Increment team hits
            if (gameState.inningHalf === 'top') {
                gameState.awayHits++;
            } else {
                gameState.homeHits++;
            }
            break;
        case 'out':
            batter.ab++;
            break;
        case 'strikeout':
            batter.ab++;
            batter.k++;
            gameState.strikeouts++;
            break;
        case 'walk':
            batter.bb++;
            break;
        case 'sacrificefly':
            // Sac fly doesn't count as AB
            break;
        case 'error':
            // Reached on Error (ROE): counts as AB but NOT a hit
            // This lowers batting average since AB increases but H doesn't
            batter.ab++;
            // Note: Team hits are NOT incremented for errors
            break;
    }
    
    nextBatter();
    updateDisplay();
}

// Show message with animation
function showMessage(text) {
    messageEl.innerHTML = text;
    messageEl.style.animation = 'none';
    setTimeout(() => {
        messageEl.style.animation = 'fadeIn 0.3s ease-in';
    }, 10);
}

// Pitch input handlers
function processContact(type) {
    saveState(); // Save state before action
    stopHomeRunAnimation();
    // Directly process the contact without quality selection
    let outcome = determineOutcome(type);
    executeOutcome(outcome);
    resetCount();
}

function backWallHomeRun() {
    saveState(); // Save state before action
    stopHomeRunAnimation();
    gameState.lastPlay = 'Back Wall Home Run';
    homeRun();
    resetCount();
}

function selectContact(type) {
    // Legacy function, no longer used
}

function selectQuality(quality) {
    // Legacy function, no longer used
}

function determineOutcome(contact) {
    let outcome;
    const hasRunners = gameState.runners.first || gameState.runners.second || gameState.runners.third;
    
    if (contact === 'grounder') {
        // Real baseball stats: ~24% hits, ~72% outs, ~4% errors
        // With runners: higher chance of DP/FC
        const roll = Math.random();
        
        // Check for double play or fielder's choice first (with runners and <2 outs)
        if (hasRunners && gameState.outs < 2) {
            if (gameState.runners.first && roll < 0.12) {
                // 12% chance of double play with runner on first
                outcome = 'doubleplay';
                return outcome;
            } else if (roll < 0.17) {
                // Additional 5% chance of fielder's choice
                outcome = 'fielderschoice';
                return outcome;
            }
        }
        
        // Check for error (4% of grounders)
        if (roll < 0.04) {
            outcome = 'error';
        }
        // Singles (22% of grounders)
        else if (roll < 0.26) {
            outcome = 'single';
        }
        // Doubles (2% of grounders - rare but possible)
        else if (roll < 0.28) {
            outcome = 'double';
        }
        // Ground outs (rest, ~72%)
        else {
            outcome = 'groundout';
        }
    } else if (contact === 'linedrive') {
        // Real baseball stats: ~68% hits, ~30% outs, ~2% errors
        // Line drives have highest batting average
        const roll = Math.random();
        
        // Error on line drive (2% - misplayed or dropped)
        if (roll < 0.02) {
            outcome = 'error';
        }
        // Singles (40% of line drives)
        else if (roll < 0.42) {
            outcome = 'single';
        }
        // Doubles (25% of line drives)
        else if (roll < 0.67) {
            outcome = 'double';
        }
        // Triples (2% of line drives)
        else if (roll < 0.69) {
            outcome = 'triple';
        }
        // Home runs (1% of line drives - line drive homers are rare)
        else if (roll < 0.70) {
            outcome = 'homerun';
        }
        // Line outs (rest, ~30%)
        else {
            outcome = 'lineout';
        }
    } else if (contact === 'popup') {
        const roll = Math.random();
        if (roll < 0.75) {
            // Check for sacrifice fly
            if (hasRunners && gameState.runners.third && gameState.outs < 2 && roll < 0.20) {
                outcome = 'sacrificefly';
            } else {
                outcome = 'flyout';
            }
        } else if (roll < 0.90) {
            outcome = 'single'; // Blooper
        } else {
            outcome = 'double'; // Down the line
        }
    }
    
    return outcome;
}

function swingAndMiss() {
    saveState(); // Save state before action
    stopHomeRunAnimation();
    gameState.strikes++;
    if (gameState.strikes >= 3) {
        gameState.lastPlay = 'Strikeout';
        showMessage(`Swings and misses!<br>Strikeout by pitcher! (${gameState.strikeouts + 1} K) ⚡`);
        recordAtBat('strikeout');
        recordOut();
        resetCount();
    } else {
        showMessage(`Strike ${gameState.strikes}! ❌`);
        updateDisplay();
    }
}

function noSwing() {
    saveState(); // Save state before action
    stopHomeRunAnimation();
    // Random ball or strike
    const isBall = Math.random() > 0.5;
    if (isBall) {
        gameState.balls++;
        if (gameState.balls >= 4) {
            gameState.lastPlay = 'Walk';
            showMessage('Ball 4! Walk! Take your base! 🚶');
            recordAtBat('walk');
            hit(1, true); // Pass true to skip the "Great hit!" message
            resetCount();
        } else {
            showMessage(`Ball ${gameState.balls} 🟢`);
            updateDisplay();
        }
    } else {
        gameState.strikes++;
        if (gameState.strikes >= 3) {
            gameState.lastPlay = 'Called strikeout';
            showMessage(`Called strike three!<br>Strikeout! (${gameState.strikeouts + 1} K) 👨‍⚖️`);
            recordAtBat('strikeout');
            recordOut();
            resetCount();
        } else {
            showMessage(`Called strike ${gameState.strikes}! 📢`);
            updateDisplay();
        }
    }
}

function foulBall() {
    saveState(); // Save state before action
    stopHomeRunAnimation();
    // 10% chance foul is caught for  an out (foul pop-up)
    if (Math.random() < 0.10) {
        gameState.lastPlay = 'Foul out';
        showMessage('Foul pop-up!<br>Caught by catcher! Out! 🥎');
        showOutX('C'); // Catcher catches foul ball
        recordAtBat('out');
        recordOut();
        resetCount();
        return;
    }
    
    if (gameState.strikes < 2) {
        gameState.strikes++;
    }
    showMessage(`Foul ball! ${gameState.strikes} strike${gameState.strikes !== 1 ? 's' : ''} ⚠️`);
    updateDisplay();
}

function resetCount() {
    gameState.strikes = 0;
    gameState.balls = 0;
    updateDisplay();
}

function processHit(contact, quality) {
    // Legacy function, no longer used
    let outcome = determineOutcome(contact);
    executeOutcome(outcome);
}

function executeOutcome(outcome) {
    switch(outcome) {
        case 'single':
            gameState.lastPlay = 'Single';
            recordAtBat('hit');
            hit(1);
            break;
        case 'double':
            gameState.lastPlay = 'Double';
            recordAtBat('hit');
            hit(2);
            break;
        case 'triple':
            gameState.lastPlay = 'Triple';
            recordAtBat('hit');
            hit(3);
            break;
        case 'homerun':
            gameState.lastPlay = 'Home Run';
            recordAtBat('hit');
            homeRun();
            break;
        case 'groundout':
            gameState.lastPlay = 'Ground out';
            const groundOutData = [
                { msg: 'Ground ball to short!<br>Out at first! ⚾', pos: 'SS' },
                { msg: 'Grounder to second!<br>Throws to first for the out! ⚾', pos: '2B' },
                { msg: 'Ground ball!<br>Routine play at first! ⚾', pos: 'SS' },
                { msg: 'Chopper to third!<br>Out at first! ⚾', pos: 'base3' },
                { msg: 'Ground ball up the middle!<br>Second baseman makes the play! ⚾', pos: '2B' },
                { msg: 'Slow roller to the mound!<br>Pitcher gets the out at first! ⚾', pos: 'P' },
                { msg: 'Ground ball to first!<br>Unassisted putout! ⚾', pos: 'base1' },
                { msg: 'Weak grounder!<br>Easy out at first! ⚾', pos: 'SS' }
            ];
            const groundOut = groundOutData[Math.floor(Math.random() * groundOutData.length)];
            showMessage(groundOut.msg);
            showOutX(groundOut.pos);
            recordAtBat('out');
            recordOut();
            break;
        case 'flyout':
            gameState.lastPlay = 'Fly out';
            
            // Check if runner on third can tag up (60% of fly balls are deep enough)
            if (gameState.runners.third && Math.random() < 0.60) {
                recordAtBat('out');
                tagUpAttempt();
            } else {
                // Regular flyout - no tag up
                const flyOutData = [
                    { msg: 'Fly ball to left field!<br>Runner under it for the catch! 🥎', pos: 'LF' },
                    { msg: 'Pop fly to center!<br>Easy catch for the out! 🥎', pos: 'CF' },
                    { msg: 'Fly ball to right!<br>Outfielder settles under it! 🥎', pos: 'RF' },
                    { msg: 'High fly to deep center!<br>Warning track catch! 🥎', pos: 'CF' },
                    { msg: 'Pop fly in foul territory!<br>First baseman makes the catch! 🥎', pos: 'base1' },
                    { msg: 'Fly ball to shallow left!<br>Diving catch! What a play! 🥎', pos: 'LF' },
                    { msg: 'Pop up behind second!<br>Shortstop calls it and makes the catch! 🥎', pos: 'SS' },
                    { msg: 'Fly ball to right-center!<br>Outfielder runs it down! 🥎', pos: 'RF' }
                ];
                const flyOut = flyOutData[Math.floor(Math.random() * flyOutData.length)];
                showMessage(flyOut.msg);
                showOutX(flyOut.pos);
                recordAtBat('out');
                recordOut();
            }
            break;
        case 'lineout':
            gameState.lastPlay = 'Line out';
            const lineOutData = [
                { msg: 'Line drive to short!<br>Shortstop snags it! 🧤', pos: 'SS' },
                { msg: 'Screaming liner to third!<br>Third baseman stabs at it and makes the catch! 🧤', pos: 'base3' },
                { msg: 'Line drive up the middle!<br>Second baseman dives and gets it! 🧤', pos: '2B' },
                { msg: 'Hard liner to first!<br>Nice reflexes for the out! 🧤', pos: 'base1' },
                { msg: 'Line drive to left field!<br>Left fielder charges in and makes the catch! 🧤', pos: 'LF' },
                { msg: 'Rocket to right field!<br>Diving catch! 🧤', pos: 'RF' },
                { msg: 'Line drive back at the pitcher!<br>Pitcher snares it! Great reaction! 🧤', pos: 'P' }
            ];
            const lineOut = lineOutData[Math.floor(Math.random() * lineOutData.length)];
            showMessage(lineOut.msg);
            showOutX(lineOut.pos);
            recordAtBat('out');
            recordOut();
            break;
        case 'fielderschoice':
            gameState.lastPlay = "Fielder's choice";
            recordAtBat('out');
            fieldersChoice();
            break;
        case 'doubleplay':
            gameState.lastPlay = 'Double play';
            recordAtBat('out');
            doublePlay();
            break;
        case 'sacrificefly':
            gameState.lastPlay = 'Sacrifice fly';
            recordAtBat('sacrificefly');
            sacrificeFly();
            break;
        case 'error':
            gameState.lastPlay = 'Error';
            const errorMessages = [
                'Ground ball to short!<br>Bobbled! Error! Runner safe at first! ⚠️',
                'Grounder to second!<br>Ball goes through the legs! Error! 🙈',
                'Ground ball to third!<br>Throw is wild! Error! Runner safe! ⚠️',
                'Line drive to left!<br>Dropped! Error on the outfielder! 🥎',
                'Ground ball!<br>Bad hop! Ball gets by the fielder! Error! ⚠️',
                'Routine grounder!<br>Fielder boots it! Error! Safe at first! 🙈',
                'Line drive!<br>Off the glove! Error! Runner reaches! ⚠️',
                'Ground ball up the middle!<br>Misplayed! Error! Safe! ⚠️',
                'Sharp grounder!<br>Charging in, can\'t handle it! Error! 🙈',
                'Fly ball to center!<br>Misjudged! Drops in! Error! ⚠️'
            ];
            showMessage(errorMessages[Math.floor(Math.random() * errorMessages.length)]);
            // Increment team errors (defensive team makes the error)
            if (gameState.inningHalf === 'top') {
                gameState.homeErrors++; // Defensive error by home team
            } else {
                gameState.awayErrors++; // Defensive error by away team
            }
            // Record at-bat (error doesn't count as AB or hit, but advances batter)
            recordAtBat('error');
            // Batter reaches base on error (treated like a single for base running)
            hit(1, true); // Pass true to skip the "Great hit!" message
            break;
    }
}

// Fielder's choice - batter safe, lead runner out
function fieldersChoice() {
    gameState.outs += 1;
    
    if (gameState.outs >= 3) {
        gameState.lastPlay = "Fielder's choice";
        recordOut();
        return;
    }
    
    // Remove lead runner, batter goes to first
    let fcMessages = [];
    let outBase = null;
    if (gameState.runners.third) {
        gameState.runners.third = false;
        outBase = 'home';
        fcMessages = [
            "Fielder's choice!<br>Runner OUT at home! ⚾",
            "Fielder's choice!<br>Throw gets the runner! OUT! ⚾",
            "Fielder's choice!<br>Runner caught in rundown! OUT! ⚾"
        ];
    } else if (gameState.runners.second) {
        gameState.runners.second = false;
        outBase = 3;
        fcMessages = [
            "Fielder's choice!<br>Runner OUT at third! ⚾",
            "Fielder's choice!<br>Runner OUT advancing! ⚾",
            "Fielder's choice!<br>Caught in rundown! OUT! ⚾"
        ];
    } else if (gameState.runners.first) {
        gameState.runners.first = false;
        outBase = 2;
        fcMessages = [
            "Fielder's choice!<br>Force OUT at second! ⚾",
            "Fielder's choice!<br>Runner OUT at second! ⚾",
            "Fielder's choice!<br>Runner caught stealing! OUT! ⚾"
        ];
    }
    
    if (outBase !== null) {
        showOutX(outBase);
    }
    
    gameState.runners.first = true;
    showMessage(fcMessages[Math.floor(Math.random() * fcMessages.length)]);
    updateDisplay();
}

// Double play - two outs
function doublePlay() {
    gameState.outs += 2;
    
    const dpMessages = [
        'Ground ball to short!<br>6-4-3 double play! 🔄',
        'Ground ball to third!<br>Around the horn! 5-4-3! 🔄',
        'Sharp grounder!<br>Shortstop to second to first! 🔄',
        'Ground ball up the middle!<br>Second to short to first! Twin killing! 🔄',
        'Ground ball!<br>4-6-3 double play! Two quick outs! 🔄',
        'Tailor-made double play!<br>6-4-3! 🔄',
        'Ground ball to pitcher!<br>1-4-3 double play! 🔄'
    ];
    
    if (gameState.outs >= 3) {
        gameState.outs = 3;
        gameState.lastPlay = 'Double play';
        showMessage('Double play!<br>Inning over! 🔄');
        recordOut();
        return;
    }
    
    // Show X at first base (double play almost always at 1st base)
    showOutX(1);
    // Also show X at second base after a delay
    setTimeout(() => showOutX(2), 400);
    
    // Clear all runners
    gameState.runners = {
        first: false,
        second: false,
        third: false
    };
    
    showMessage(dpMessages[Math.floor(Math.random() * dpMessages.length)]);
    updateDisplay();
}

// Tag up attempt - runner on third tries to score on fly ball
function tagUpAttempt() {
    gameState.outs += 1;
    
    // 85% chance runner scores, 15% chance thrown out at home
    const scores = Math.random() < 0.85;
    
    if (scores) {
        // Runner successfully tags and scores (unless it's the 3rd out)
        if (gameState.outs < 3) {
            flashHomePlate();
            if (gameState.inningHalf === 'top') {
                gameState.awayScore += 1;
                gameState.currentInningRuns += 1;
            } else {
                gameState.homeScore += 1;
                gameState.currentInningRuns += 1;
            }
            gameState.runners.third = false;
            
            const successMessages = [
                { msg: 'Deep fly to left field!<br>Runner tags and scores! OUT! 🎯', pos: 'LF' },
                { msg: 'Fly ball to center!<br>Runner tags up and beats the throw! OUT! 🎯', pos: 'CF' },
                { msg: 'Long fly to right!<br>Tag up! Runner scores easily! OUT! 🎯', pos: 'RF' },
                { msg: 'Deep fly to left-center!<br>Throw home is too late! Run scores! OUT! 🎯', pos: 'LF' },
                { msg: 'Warning track catch in center!<br>Runner tags and trots home! OUT! 🎯', pos: 'CF' }
            ];
            const msg = successMessages[Math.floor(Math.random() * successMessages.length)];
            showMessage(msg.msg);
            showOutX(msg.pos);
        } else {
            // 3rd out - runner doesn't score
            gameState.runners.third = false;
            const msg = 'Deep fly ball caught!<br>3rd out - runner cannot score! 🥎';
            showMessage(msg);
            showOutX('CF');
        }
    } else {
        // Runner thrown out at home!
        gameState.outs += 1; // Double play - batter out + runner out
        gameState.runners.third = false;
        
        const thrownOutMessages = [
            'Deep fly to left!<br>Runner tags... CANNON throw home! OUT! Double play! 🔥',
            'Fly ball to right!<br>Strong arm! Throw beats the runner! OUT at home! 🏠',
            'Deep fly to center!<br>Perfect throw! Runner OUT at the plate! 🏠',
            'Fly ball caught!<br>Relay throw nails the runner at home! Double play! 🔥'
        ];
        showMessage(thrownOutMessages[Math.floor(Math.random() * thrownOutMessages.length)]);
        showOutX('home'); // Show out at home plate
    }
    
    if (gameState.outs >= 3) {
        recordOut();
        return;
    }
    
    updateDisplay();
}

// Sacrifice fly - runner scores, batter out
function sacrificeFly() {
    gameState.outs += 1;
    
    // Only score runner from third if not the 3rd out, or if it is the 3rd out,
    // the runner tags and scores before the out is made (which is the assumption here)
    // However, if this became the 3rd out, this assumes it was not a force out
    if (gameState.runners.third && gameState.outs < 3) {
        flashHomePlate();
        if (gameState.inningHalf === 'top') {
            gameState.awayScore += 1;
            gameState.currentInningRuns += 1;
        } else {
            gameState.homeScore += 1;
            gameState.currentInningRuns += 1;
        }
        gameState.runners.third = false;
    } else if (gameState.runners.third && gameState.outs >= 3) {
        // 3rd out - runner doesn't score
        gameState.runners.third = false;
    }
    
    const sacFlyData = [
        { msg: 'Fly ball to deep center!<br>Runner tags and scores! OUT at first! 🎯', pos: 'CF' },
        { msg: 'Fly ball to left field!<br>Runner scores on the sac fly! OUT! 🎯', pos: 'LF' },
        { msg: 'Deep fly to right field!<br>Tag up! Runner scores! Batter OUT! 🎯', pos: 'RF' },
        { msg: 'Long fly ball to center!<br>Runner tags from third and scores! OUT! 🎯', pos: 'CF' },
        { msg: 'Fly ball to left-center!<br>Throw home is too late! Run scores! OUT! 🎯', pos: 'LF' }
    ];
    
    const sacFly = sacFlyData[Math.floor(Math.random() * sacFlyData.length)];
    
    if (gameState.outs >= 3) {
        gameState.lastPlay = 'Sacrifice fly';
        const thirdOutMsg = sacFly.msg.replace('scores', 'cannot score - 3rd out');
        showMessage(thirdOutMsg);
        showOutX(sacFly.pos);
        recordOut();
        return;
    }
    
    showMessage(sacFly.msg);
    showOutX(sacFly.pos);
    updateDisplay();
}

// Handle hits
function hit(bases, skipMessage = false) {
    let hitType;
    let runsScored = 0;
    let extraBaseAttempt = false;
    let thrownOut = false;
    
    // Score runners based on hit type
    if (bases >= 1 && gameState.runners.third) runsScored++;
    if (bases >= 2 && gameState.runners.second) runsScored++;
    if (bases >= 3 && gameState.runners.first) runsScored++;
    
    // Advance remaining runners
    const newRunners = {
        first: false,
        second: false,
        third: false
    };
    
    if (bases === 1) {
        // Single
        hitType = 'Single';
        newRunners.first = true;
        if (gameState.runners.second) newRunners.third = true;
        if (gameState.runners.first) newRunners.second = true;
        if (!skipMessage) flashRunner(1); // Flash first base only for actual hits
    } else if (bases === 2) {
        // Double - runner on 1st might try to score
        hitType = 'Double';
        newRunners.second = true;
        
        if (gameState.runners.first) {
            // 30% chance runner tries to score from 1st on a double
            if (Math.random() < 0.30) {
                extraBaseAttempt = true;
                // 45% chance they're thrown out
                if (Math.random() < 0.45) {
                    thrownOut = true;
                    gameState.outs++;
                    showOutX('home'); // Out at home plate
                } else {
                    runsScored++;
                }
            } else {
                newRunners.third = true;
            }
        }
        flashRunner(2); // Flash second base
    } else if (bases === 3) {
        // Triple - runner on 1st might try to score (normally stops at 2nd)
        hitType = 'Triple';
        newRunners.third = true;
        
        if (gameState.runners.first) {
            // 20% chance runner tries to score from 1st on a triple
            if (Math.random() < 0.20) {
                extraBaseAttempt = true;
                // 40% chance they're thrown out
                if (Math.random() < 0.40) {
                    thrownOut = true;
                    gameState.outs++;
                    showOutX('home'); // Out at home plate
                } else {
                    runsScored++;
                }
            } else {
                // Normal advance - 1st goes to 2nd on triple
                // Actually on a triple, runner on 1st usually scores, so let's score them
                runsScored++;
            }
        }
        flashRunner(3); // Flash third base
    }
    
    animateRunners();
    
    setTimeout(() => {
        gameState.runners = newRunners;
        
        // Flash home plate if runs scored
        if (runsScored > 0) {
            flashHomePlate();
        }
        
        // Add runs to correct team
        if (gameState.inningHalf === 'top') {
            gameState.awayScore += runsScored;
            gameState.currentInningRuns += runsScored;
        } else {
            gameState.homeScore += runsScored;
            gameState.currentInningRuns += runsScored;
        }
        
        // Only show message for actual hits, not walks
        if (!skipMessage) {
            let message = `${hitType}! Great hit!`;
            
            if (extraBaseAttempt) {
                if (thrownOut) {
                    message += '<br>Runner attempts extra base! OUT at home!';
                } else {
                    message += '<br>Runner takes extra base! Scores from first!';
                }
            } else if (runsScored > 0) {
                message += `<br>${runsScored} run${runsScored > 1 ? 's' : ''} scored!`;
            }
            
            message += ' 🎉';
            
            showMessage(message);
        }
        
        // Check if 3 outs from extra base attempt
        if (gameState.outs >= 3) {
            recordOut();
        } else {
            updateDisplay();
        }
    }, 500);
}

// Handle home run
function homeRun() {
    // Record the hit for the batter
    recordAtBat('hit');
    
    let runsScored = 1; // Batter
    if (gameState.runners.first) runsScored++;
    if (gameState.runners.second) runsScored++;
    if (gameState.runners.third) runsScored++;
    
    // Launch fireworks!
    launchFireworks();
    
    // Variety of home run descriptions
    const homeRunDescriptions = [
        'Deep blast to left field!',
        'Monster shot to center!',
        'Towering fly ball to right!',
        'Sky-high bomb to left-center!',
        'Crushed over the right field fence!',
        'Moonshot to deep center!',
        'Line drive home run! Gone to left!',
        'No doubt about it! Deep to right!',
        'Upper deck shot to left!',
        'Absolute bomb to center field!',
        'Majestic fly ball! Out to right!',
        'Way back! Deep left field!',
        'High and deep to right-center!',
        'Hammered to left! Going, going, gone!',
        'Rocket shot over the center field wall!'
    ];
    
    const description = homeRunDescriptions[Math.floor(Math.random() * homeRunDescriptions.length)];
    
    // Animate batter running around bases
    animateHomeRunBases();
    
    setTimeout(() => {
        // Flash home plate if runs scored
        if (runsScored > 0) {
            flashHomePlate();
        }
        
        // Add runs to correct team
        if (gameState.inningHalf === 'top') {
            gameState.awayScore += runsScored;
            gameState.currentInningRuns += runsScored;
        } else {
            gameState.homeScore += runsScored;
            gameState.currentInningRuns += runsScored;
        }
        
        // Clear all bases
        gameState.runners = {
            first: false,
            second: false,
            third: false
        };
        
        showMessage(`${description}<br>🎉 HOME RUN! ${runsScored} run${runsScored > 1 ? 's' : ''} scored! 🎇`);
        updateDisplay();
    }, 1300);
    
    celebrateHomeRun();
}

// Convert number to ordinal (1st, 2nd, 3rd, etc.)
function getOrdinal(n) {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

// Record an out
function recordOut() {
    gameState.outs += 1;
    
    if (gameState.outs >= 3) {
        // Show what caused the third out
        setTimeout(() => {
            const battingTeam = gameState.inningHalf === 'top' ? 'Away' : 'Home';
            const inningOrdinal = getOrdinal(gameState.inning);
            
            // Record runs for this inning
            if (gameState.inningHalf === 'top') {
                gameState.awayInnings[gameState.inning - 1] = gameState.currentInningRuns;
                showMessage(`${gameState.lastPlay}! End of Top ${inningOrdinal}. ${battingTeam} scored ${gameState.currentInningRuns} run${gameState.currentInningRuns !== 1 ? 's' : ''}.`);
                gameState.inningHalf = 'bottom';
                // Set home's current inning to 0 to start
                gameState.homeInnings[gameState.inning - 1] = 0;
            } else {
                gameState.homeInnings[gameState.inning - 1] = gameState.currentInningRuns;
                showMessage(`${gameState.lastPlay}! End of ${inningOrdinal}. ${battingTeam} scored ${gameState.currentInningRuns} run${gameState.currentInningRuns !== 1 ? 's' : ''}.`);
                gameState.inning += 1;
                gameState.inningHalf = 'top';
                // Set away's next inning to 0 to start if it exists
                if (gameState.inning <= 9) {
                    gameState.awayInnings[gameState.inning - 1] = 0;
                }
            }
            
            gameState.outs = 0;
            gameState.currentInningRuns = 0;
            resetCount();
            
            // Clear bases at end of half inning
            gameState.runners = {
                first: false,
                second: false,
                third: false
            };
            
            updateDisplay();
        }, 500);
    }
    
    updateDisplay();
}

// Manual controls
function manualBall() {
    saveState(); // Save state before action
    gameState.balls++;
    if (gameState.balls >= 4) {
        gameState.lastPlay = 'Walk';
        showMessage('Ball 4! Walk! 🚶');
        hit(1, true); // Pass true to skip the "Great hit!" message
        resetCount();
    } else {
        showMessage(`Ball ${gameState.balls}`);
        updateDisplay();
    }
}

function manualStrike() {
    saveState(); // Save state before action
    gameState.strikes++;
    if (gameState.strikes >= 3) {
        gameState.lastPlay = 'Strikeout';
        showMessage(`Strike three!<br>Strikeout by pitcher! (${gameState.strikeouts + 1} K) ⚡`);
        recordAtBat('strikeout');
        recordOut();
        resetCount();
    } else {
        showMessage(`Strike ${gameState.strikes}`);
        updateDisplay();
    }
}

function manualWalk() {
    saveState(); // Save state before action
    gameState.lastPlay = 'Walk';
    showMessage('Walk! Take your base! 🚶');
    recordAtBat('walk');
    hit(1, true); // Pass true to skip the "Great hit!" message
    resetCount();
}

// Advance all runners by one base
function advanceAllRunners() {
    // Check if any runners are on base
    if (!gameState.runners.first && !gameState.runners.second && !gameState.runners.third) {
        showMessage('No runners on base to advance! 🤷');
        return;
    }
    
    saveState(); // Save state before action
    
    let runsScored = 0;
    
    // Move runners forward one base
    const newRunners = {
        first: false,
        second: false,
        third: false
    };
    
    // Runner on third scores
    if (gameState.runners.third) {
        runsScored++;
    }
    
    // Runner on second goes to third
    if (gameState.runners.second) {
        newRunners.third = true;
    }
    
    // Runner on first goes to second
    if (gameState.runners.first) {
        newRunners.second = true;
    }
    
    gameState.runners = newRunners;
    
    // Flash home plate if runs scored
    if (runsScored > 0) {
        flashHomePlate();
        
        // Add runs to correct team
        if (gameState.inningHalf === 'top') {
            gameState.awayScore += runsScored;
            gameState.currentInningRuns += runsScored;
        } else {
            gameState.homeScore += runsScored;
            gameState.currentInningRuns += runsScored;
        }
    }
    
    showMessage(`Runners advanced!<br>${runsScored > 0 ? runsScored + ' run(s) score! 🎉' : 'No runs score.'}`);
    updateDisplay();
}

// Process bunt
function processBunt() {
    saveState(); // Save state before action
    
    const roll = Math.random();
    const hasRunners = gameState.runners.first || gameState.runners.second || gameState.runners.third;
    
    // 20% chance of foul bunt
    if (roll < 0.20) {
        const foulMessages = [
            'Bunted foul!<br>Off to the side! ⚠️',
            'Foul bunt!<br>Rolled into foul territory! ⚠️',
            'Bunted foul down the line!<br>Foul ball! ⚠️',
            'Popped it up foul!<br>Out of play! ⚠️',
            'Foul bunt!<br>Went wide! ⚠️'
        ];
        
        if (gameState.strikes >= 2) {
            // Strikeout on foul bunt with 2 strikes
            gameState.lastPlay = 'Strikeout - foul bunt';
            showMessage('Bunted foul with 2 strikes!<br>That\'s a strikeout! ⚡');
            recordAtBat('strikeout');
            recordOut();
            resetCount();
        } else {
            // Add a strike
            gameState.strikes++;
            showMessage(`${foulMessages[Math.floor(Math.random() * foulMessages.length)]}<br>Strike ${gameState.strikes}!`);
            updateDisplay();
        }
        return;
    }
    
    // Adjust remaining probabilities (now out of 0.80)
    const adjustedRoll = (roll - 0.20) / 0.80;
    
    if (hasRunners) {
        // Sacrifice bunt situation - Real stats: ~75% success, ~12% lead runner out, ~8% failed, ~5% DP
        
        if (adjustedRoll < 0.75) {
            // Successful sacrifice - batter out, runners advance
            gameState.lastPlay = 'Sacrifice bunt';
            const sacBuntMessages = [
                'Perfect sacrifice bunt!<br>Batter out, runner advances! 🥎',
                'Good bunt down the line!<br>Throws to first. OUT! Runner advances! 🥎',
                'Bunt to third!<br>Takes the out at first. Runner safe at second! 🥎',
                'Textbook sacrifice!<br>Batter out, runner moves up! 🥎',
                'Squeeze bunt executed!<br>Batter out at first, runner advances! 🥎'
            ];
            showMessage(sacBuntMessages[Math.floor(Math.random() * sacBuntMessages.length)]);
            showOutX(1); // Show X at first base
            recordAtBat('sacrificebunt');
            
            // Advance runners before recording the out
            // BUT: Check if this will be the 3rd out - if so, NO runs score (force play)
            let runsScored = 0;
            const newRunners = {
                first: false,
                second: false,
                third: false
            };
            
            // CHECK: Will this be the 3rd out? If so, don't score runs (it's a force out)
            const willBeThirdOut = (gameState.outs >= 2);
            
            // Runner on third scores ONLY if not the 3rd out
            if (gameState.runners.third && !willBeThirdOut) {
                runsScored++;
            }
            
            // Runner on second goes to third
            if (gameState.runners.second) {
                newRunners.third = true;
            }
            
            // Runner on first goes to second
            if (gameState.runners.first) {
                newRunners.second = true;
            }
            
            gameState.runners = newRunners;
            
            // Flash home plate and add runs ONLY if not 3rd out
            if (runsScored > 0 && !willBeThirdOut) {
                flashHomePlate();
                
                // Add runs to correct team
                if (gameState.inningHalf === 'top') {
                    gameState.awayScore += runsScored;
                    gameState.currentInningRuns += runsScored;
                } else {
                    gameState.homeScore += runsScored;
                    gameState.currentInningRuns += runsScored;
                }
            }
            
            recordOut();
            
        } else if (adjustedRoll < 0.87) {
            // Lead runner thrown out - fielder's choice
            gameState.lastPlay = 'Bunt - lead runner out';
            
            let outLocation = '';
            const newRunners = {
                first: true, // Batter reaches
                second: false,
                third: false
            };
            
            if (gameState.runners.third) {
                // Runner thrown out at home
                outLocation = 'home';
                const messages = [
                    'Bunt to third!<br>Throw home! OUT at the plate! 🏠',
                    'Squeeze play!<br>Catcher has the plate! Runner OUT! 🏠',
                    'Bunt fielded quickly!<br>Throw home beats the runner! OUT! 🏠'
                ];
                showMessage(messages[Math.floor(Math.random() * messages.length)]);
                // Other runners advance
                if (gameState.runners.second) newRunners.third = true;
                if (gameState.runners.first) newRunners.second = true;
            } else if (gameState.runners.second) {
                // Runner thrown out at third
                outLocation = 3;
                const messages = [
                    'Bunt to pitcher!<br>Throw to third! Runner OUT! 🧤',
                    'Bunt fielded!<br>Quick throw to third gets the lead runner! OUT! 🧤',
                    'Charging third baseman!<br>Tags the bag! Runner OUT! 🧤'
                ];
                showMessage(messages[Math.floor(Math.random() * messages.length)]);
                // Runner from first advances to second
                if (gameState.runners.first) newRunners.second = true;
            } else {
                // Runner thrown out at second
                outLocation = 2;
                const messages = [
                    'Bunt to second!<br>Flips to the shortstop! OUT at second! 🧤',
                    'Bunt up the middle!<br>Throw to second! Lead runner OUT! 🧤',
                    'Pitcher fields it!<br>Throw to second base! OUT! 🧤'
                ];
                showMessage(messages[Math.floor(Math.random() * messages.length)]);
            }
            
            showOutX(outLocation);
            gameState.runners = newRunners;
            recordAtBat('out');
            recordOut();
            
        } else if (adjustedRoll < 0.95) {
            // Failed bunt - batter out, runners don't advance
            gameState.lastPlay = 'Failed bunt';
            const failedMessages = [
                'Popped up the bunt!<br>Easy catch! OUT! Runners hold! 🧤',
                'Bunted too hard!<br>Quick throw to first! OUT! No advance! 🧤',
                'Bunt right to the pitcher!<br>OUT at first! Runners stay! 🧤',
                'Fouled off for strike three!<br>Strikeout on the bunt! Runners hold! ⚡'
            ];
            showMessage(failedMessages[Math.floor(Math.random() * failedMessages.length)]);
            showOutX(1); // Show X at first base
            recordAtBat('out');
            recordOut();
            
        } else {
            // Double play (only possible with < 2 outs)
            if (gameState.outs < 2 && hasRunners) {
                gameState.lastPlay = 'Bunt double play';
                const dpMessages = [
                    'Popped up bunt!<br>Caught! Doubles off the runner! DOUBLE PLAY! 🔥',
                    'Line drive bunt!<br>Caught and doubled off first! DOUBLE PLAY! 🔥',
                    'Bunt to pitcher!<br>Throws to second, relay to first! DOUBLE PLAY! 🔥'
                ];
                showMessage(dpMessages[Math.floor(Math.random() * dpMessages.length)]);
                recordAtBat('out');
                doublePlay();
            } else {
                // Can't have DP with 2 outs, so treat as failed bunt instead
                gameState.lastPlay = 'Failed bunt';
                const failedMessages = [
                    'Popped up the bunt!<br>Easy catch! OUT! Runners hold! 🧤',
                    'Bunted too hard!<br>Quick throw to first! OUT! No advance! 🧤'
                ];
                showMessage(failedMessages[Math.floor(Math.random() * failedMessages.length)]);
                showOutX(1);
                recordAtBat('out');
                recordOut();
            }
        }
        
    } else {
        // No runners - bunting for a hit
        // Real stats: ~25% successful, ~75% out
        
        if (adjustedRoll < 0.25) {
            // Successful bunt for hit
            gameState.lastPlay = 'Bunt single';
            const buntHitMessages = [
                'Perfect drag bunt!<br>Safe at first! 🥎',
                'Bunt down the third base line!<br>Beats the throw! Safe! 🥎',
                'Push bunt to the right side!<br>Nobody there! Safe! 🥎',
                'Bunt for a hit!<br>Great speed! Safe at first! 🥎',
                'Surprise bunt!<br>Defense caught off guard! Safe! 🥎'
            ];
            showMessage(buntHitMessages[Math.floor(Math.random() * buntHitMessages.length)]);
            recordAtBat('hit');
            hit(1);
        } else {
            // Bunt out at first
            gameState.lastPlay = 'Bunt out';
            const buntOutMessages = [
                'Bunt to pitcher!<br>Throws to first. OUT! 🧤',
                'Bunted too hard!<br>Third baseman charges, OUT at first! 🧤',
                'Popped up the bunt!<br>Easy catch! OUT! 🧤',
                'Bunt to catcher!<br>Quick throw to first. OUT! 🧤',
                'Bunt fielded cleanly!<br>Throw to first. OUT! 🧤'
            ];
            showMessage(buntOutMessages[Math.floor(Math.random() * buntOutMessages.length)]);
            showOutX(1); // Show X at first base
            recordAtBat('out');
            recordOut();
        }
    }
    
    resetCount();
}

function manualSingle() {
    saveState(); // Save state before action
    gameState.lastPlay = 'Single';
    recordAtBat('hit');
    hit(1);
    resetCount();
}

function manualDouble() {
    saveState(); // Save state before action
    gameState.lastPlay = 'Double';
    recordAtBat('hit');
    hit(2);
    resetCount();
}

function manualTriple() {
    saveState(); // Save state before action
    gameState.lastPlay = 'Triple';
    recordAtBat('hit');
    hit(3);
    resetCount();
}

function manualHomeRun() {
    saveState(); // Save state before action
    gameState.lastPlay = 'Home Run';
    homeRun(); // homeRun() already calls recordAtBat('hit')
    resetCount();
}

function manualOut() {
    // Prevent processing if already at 3 outs (for rapid clicking)
    if (gameState.outs >= 3) {
        return;
    }
    
    saveState(); // Save state before action
    gameState.lastPlay = 'Out at first';
    showMessage('Out at first base! 🧤');
    showOutX(1); // Show X at first base
    
    // Record the at-bat for current batter
    const batter = getCurrentBatter();
    batter.ab++;
    
    // Always advance to next batter (lineup continues even after 3rd out)
    nextBatter();
    
    // Record the out
    recordOut();
    resetCount();
}

// Start a new game
function newGame() {
    if (confirm('Start a new game? Current scores will be reset.')) {
        gameState = {
            homeScore: 0,
            awayScore: 0,
            inning: 1,
            inningHalf: 'top',
            outs: 0,
            strikes: 0,
            balls: 0,
            runners: {
                first: false,
                second: false,
                third: false
            },
            currentContact: null,
            homeInnings: ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
            awayInnings: ['-', '-', '-', '-', '-', '-', '-', '-', '-'],
            currentInningRuns: 0,
            lastPlay: ''
        };
        // Set first inning for away to 0
        gameState.awayInnings[0] = 0;
        showMessage('New game started! Play Ball! ⚾️');
        updateDisplay();
    }
}

// Visual celebration for home run
function celebrateHomeRun() {
    const scoreCard = document.querySelector('.score-card.home');
    scoreCard.style.animation = 'none';
    setTimeout(() => {
        scoreCard.style.animation = 'pulse 0.5s ease-in-out';
    }, 10);
}

// Add pulse animation
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }
`;
document.head.appendChild(style);

// Manual score adjustment
function adjustScore(team, amount) {
    if (team === 'home') {
        gameState.homeScore = Math.max(0, gameState.homeScore + amount);
    } else {
        gameState.awayScore = Math.max(0, gameState.awayScore + amount);
    }
    updateDisplay();
}

// Toggle manual control buttons
function toggleManualButtons() {
    const manualControls = document.getElementById('manualControls');
    const toggleLabel = document.getElementById('toggleLabel');
    
    if (manualControls.style.display === 'none') {
        manualControls.style.display = 'block';
        toggleLabel.textContent = 'Hide Manual Controls';
    } else {
        manualControls.style.display = 'none';
        toggleLabel.textContent = 'Show Manual Controls';
    }
}



// Random outcome generator
function randomOutcome() {
    saveState(); // Save state before action
    const groundOutMsgs = [
        'Ground ball to short!<br>Out at first! ⚾',
        'Grounder to second!<br>Out! ⚾',
        'Ground ball!<br>Routine play at first! ⚾'
    ];
    const flyOutMsgs = [
        'Fly ball to center!<br>Caught! 🦅',
        'Pop fly!<br>Easy catch! 🦅',
        'Fly ball to left!<br>Out! 🦅'
    ];
    const popupMsgs = [
        'Pop up!<br>Infielder calls it! 🧤',
        'High pop-up!<br>Caught! 🧤',
        'Pop fly!<br>Easy out! 🧤'
    ];
    
    const outcomes = [
        { type: 'single', weight: 25, action: () => { recordAtBat('hit'); hit(1); } },
        { type: 'double', weight: 15, action: () => { recordAtBat('hit'); hit(2); } },
        { type: 'triple', weight: 3, action: () => { recordAtBat('hit'); hit(3); } },
        { type: 'homerun', weight: 8, action: () => { recordAtBat('hit'); homeRun(); } },
        { type: 'groundout', weight: 20, action: () => { showMessage(groundOutMsgs[Math.floor(Math.random() * groundOutMsgs.length)]); recordAtBat('out'); recordOut(); } },
        { type: 'flyout', weight: 15, action: () => { showMessage(flyOutMsgs[Math.floor(Math.random() * flyOutMsgs.length)]); recordAtBat('out'); recordOut(); } },
        { type: 'popup', weight: 8, action: () => { showMessage(popupMsgs[Math.floor(Math.random() * popupMsgs.length)]); recordAtBat('out'); recordOut(); } },
        { type: 'strikeout', weight: 18, action: () => { showMessage(`Strike three!<br>Strikeout! (${gameState.strikeouts + 1} K) ⚡`); recordAtBat('strikeout'); recordOut(); } },
        { type: 'walk', weight: 10, action: () => { showMessage('Walk! Take your base! 🚶'); recordAtBat('walk'); hit(1, true); } },
        { type: 'error', weight: 5, action: () => { showMessage('Error! Safe at first! 😬'); hit(1, true); } },
        { type: 'foul', weight: 3, action: () => showMessage('Foul ball! ⚠️') }
    ];
    
    // Weighted random selection
    const totalWeight = outcomes.reduce((sum, o) => sum + o.weight, 0);
    let random = Math.random() * totalWeight;
    
    for (const outcome of outcomes) {
        random -= outcome.weight;
        if (random <= 0) {
            outcome.action();
            return;
        }
    }
}

// Initialize display
updateDisplay();
